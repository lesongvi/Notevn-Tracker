self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "2747a87364f0c35492e9",
    "url": "app.bundle.js"
  },
  {
    "revision": "85b12af60ddf57ea6860c3b16407fd52",
    "url": "app.bundle.js.LICENSE"
  },
  {
    "revision": "9bba57743560dc4aebdd",
    "url": "background.bundle.js"
  },
  {
    "revision": "e7d5340dde137628807004374a9b7592",
    "url": "background.bundle.js.LICENSE"
  },
  {
    "revision": "e13243a25d072347cedb",
    "url": "contentScript.bundle.js"
  },
  {
    "revision": "85b12af60ddf57ea6860c3b16407fd52",
    "url": "contentScript.bundle.js.LICENSE"
  },
  {
    "revision": "3f6812e31479166d2bce1b388b3b295d",
    "url": "popup.html"
  },
  {
    "revision": "2747a87364f0c35492e9",
    "url": "static/css/app.65e06f69.css"
  },
  {
    "revision": "05acfdb568b3df49ad31355b19495d4a",
    "url": "static/media/ionicons.05acfdb5.woff"
  },
  {
    "revision": "24712f6c47821394fba7942fbb52c3b2",
    "url": "static/media/ionicons.24712f6c.ttf"
  },
  {
    "revision": "2c2ae068be3b089e0a5b59abb1831550",
    "url": "static/media/ionicons.2c2ae068.eot"
  },
  {
    "revision": "621bd386841f74e0053cb8e67f8a0604",
    "url": "static/media/ionicons.621bd386.svg"
  }
]);